const CONFIG = {
    introTitle: 'Babe à!',
    introDesc: `Trái đất vốn lạ thường
    Mà sao em cứ đi nhầm đường
    Lạc vào tim anh lẻ loi
    Đằng sau chữ yêu đây là thương`,
    btnIntro: 'hihi',
    title: 'Phải chăng em đã yêu ngay từ cái nhìn đầu tiên 😙',
    desc: 'Phải chăng em đã say ngay từ lúc thấy nụ cười ấy ',
    btnYes: 'Vẫn cứ là thích anh <33',
    btnNo: 'Không, Anh trai à :3',
    question:'Trên thế giới hơn 7 tỉ người mà sao em lại yêu anh <3',
    btnReply: 'Gửi cho anh <3',
    reply: 'Yêu thì yêu mà không yêu thì yêu <33333333',
    mess: 'Anh biết mà 🥰. Yêu em nhiều nhiều 😘😘',
    messDesc: 'Tối nay 7h anh qua đón nhé công chúa.',
    btnAccept: 'Okiiiii lun <3',
    messLink: 'https://www.facebook.com/anonymous0834' //link mess của các bạn. VD: https://m.me/nam.nodemy
}